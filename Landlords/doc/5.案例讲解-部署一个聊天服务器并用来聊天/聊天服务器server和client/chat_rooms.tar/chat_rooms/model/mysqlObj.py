# -*- coding: utf8 -*-
from firefly.dbentrust.dbpool import dbpool                         	#引入DBUtil在Firefly封装的模块 
																		#（补充说明：当然，你如果有已经封装好的DBUtils模块
																		#也可以调用自己的，比如那种分布式结构）
from datetime import *
import json,sys,os,time, hashlib										#载入一些基础的模块
class ConnectionMysql:
	'''连接数据库的类, 这个模块你可以自己扩展，或是增加其他功能，你懂的，本想扩展更加更能完善的模块，但考虑到这是学习，
	为了继续走通以后流程，所以简单封装了一下，在以后的笔记中，逐步完善该模块''' 
	def __init__(self):
		self.dbConfig = json.load(open('config.json', \
				'r')).get('db')											#载入配置文件
		dbpool.initPool(host = self.dbConfig['host'], \
					user = self.dbConfig['user'], \
					passwd = self.dbConfig['passwd'], \
					port = self.dbConfig['port'], \
					db = self.dbConfig['db'], \
					charset = self.dbConfig['charset'])  # wtx 这里要把名称由char改成charset!!
		self.conn = dbpool.connection()
		self.cursor = self.conn.cursor()

	def getOne(self, sqlStr):
		'''获取一条数据'''
		try:
			self.cursor.execute(sqlStr)				#给出一个例子，sqlStr是什么形式的？
			result = self.cursor.fetchone()								#获取一条数据结果
			return result
		except Exception, e:
			print ' [ ERROR ]:',e
			return False												#返回结果

	def getList(self, sqlStr):
		'''获取多条数据'''
		try:
			self.cursor.execute(sqlStr)
			result = self.cursor.fetchall()								#获取多条数据结果
			return result												#返回结果
		except Exception, e:
			print ' [ ERROR ]:',e
			return False

	def query(self, sqlStr):
		'''insert和update和delete操作'''
		if 'insert into' not in sqlStr.lower() and 'update' not in sqlStr.lower() and 'delete from' not in sqlStr.lower():
			return False
		try:
			self.cursor.execute(sqlStr)
		except Exception, e:
			print ' [ ERROR ]:',e
			return False
		if 'insert' in sqlStr.lower():
			self.cursor.execute("SELECT @@IDENTITY AS id")  
			result = cur.fetchone()  
			return result[0]
		return True

	def close(self):
		'''关闭数据库连接，重构方法'''
		self.cursor.close()
		self.conn.close()
		self.conn = False
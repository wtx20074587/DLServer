# -*- coding: utf8 -*-
__framework__ = 'Firefly v1.2.3'
__author__ = '一瞬间的错觉(Firefly)'
__secondary_author__ = 'Aeolus(QQ:251920948)'
__date__ = "$Date: 2013/11/17 $"
__license__ = "Python"
wtxdebug = True
from firefly.server.globalobject import netserviceHandle
from firefly.server.globalobject import GlobalObject
from datetime import *
import json,sys,os,time, hashlib										#载入一些基础的模块
main_root = os.path.dirname(os.path.dirname(__file__))
sys.path.append(main_root)												
from  model.mysqlObj import ConnectionMysql
sysConfig = json.load(open('config.json', 'r'))
authenticationKey = sysConfig.get("other")
authenticationKey = authenticationKey['authenticationKey']				#载入随机串

dbObject = ConnectionMysql()											#定义数据库对象全局变量

def callbackSingleClientData(_conn, callbackstr):
	if(wtxdebug):
		print 'wtx callbackSingleClientData'
	GlobalObject().netfactory.pushObject(10000, callbackstr, \
		[_conn.transport.sessionno]) ###wtx 这没理解。这个10000是什么意思？？！！


@netserviceHandle
def login_101(_conn, data): ## demo 实验，只有XXX_101这个数字是有用的，用来“对接”远程调用。前缀的名称只方便我们coder记忆。
	'''用户登陆方法'''
	global dbObject, authenticationKey,loginTempList
	#处理用户提交的数据
	data = str(data)

	if (wtxdebug):
		print 'wtx speak_10000'
		print data

	if data=='':
		returnStr = "{'status':-1, 'msg':'Pleas enter your username and password.'}|<2s|"
		return callbackSingleClientData(_conn, returnStr)
	try:
		userData = eval(data)
	except Exception, e:
		returnStr = "{'status':-5, 'msg':'Client data error, error code:-5.'}|<2s|"
		return callbackSingleClientData(_conn, returnStr)
	try:
		username = userData['u']
		password = userData['p']
	except Exception, e:
		returnStr = "{'status':-2, 'msg':'System error, error code:-2.'}|<2s|"
		return callbackSingleClientData(_conn, returnStr)
 	if userData['u']=='' or userData['p']=='':
 		returnStr = "{'status':-3, 'msg':'Pleas enter your username or password.'}|<2s|"
		return callbackSingleClientData(_conn, returnStr)
 	#这里要做参数过滤，因为是Demo所以就不再过滤了
	if dbObject.conn==False:
		returnStr = "{'status':-6, 'msg':'Sorry, System connection lose. Please contact us.'}|<2s|"
		return callbackSingleClientData(_conn, returnStr)				#连接数据库失败
	returnUserData = dbObject.getOne('select * from lo_login where user_name="'+str(userData['u'])\
		+'" and password="'+str(userData['p'])+'"')						#这里你可以在密码处加密
	if returnUserData==False or returnUserData==None:
		returnStr = "{'status':-4, 'msg':'Sorry, You username or password is error.'}|<2s|"
		return callbackSingleClientData(_conn, returnStr)
	#否则返回用户信息 , [0]id, [1]user_name, [2]password
	userkeyStr = str(returnUserData[0])+returnUserData[1]+authenticationKey
	userkeyStr = hashlib.md5(userkeyStr).hexdigest().upper()
	returnStr = '{"status":1,"userkey":"'+str(userkeyStr)+'","user_id":'+str(returnUserData[0])+',"user_name":"'+str(returnUserData[1])+'"}|<2s|'
	if(wtxdebug):
		print 'wtx22' + returnStr
	callbackSingleClientData(_conn, returnStr)							#发送验证成功消息


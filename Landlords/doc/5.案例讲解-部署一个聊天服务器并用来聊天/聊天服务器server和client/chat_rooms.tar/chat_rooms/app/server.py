# -*- coding: utf8 -*-
__framework__ = 'Firefly v1.2.3'
__author__ = '一瞬间的错觉(Firefly)'
__secondary_author__ = 'Aeolus(QQ:251920948)'
__date__ = "$Date: 2013/11/17 $"
__license__ = "Python"
wtxdebug = True

from firefly.server.globalobject import netserviceHandle
from firefly.server.globalobject import GlobalObject
from datetime import *
import json,sys,os,time, hashlib										#载入一些基础的模块

sysConfig = json.load(open('config.json', 'r'))
authenticationKey = sysConfig.get("other")
authenticationKey = authenticationKey['authenticationKey']				#载入随机串
loginTempDict = {}

def doConnectionLost(conn):
	'''当连接断开时调用的方法,这里要判断是否登陆'''
	global loginTempDict
	if conn.transport.sessionno in loginTempDict:
		lis = GlobalObject().netfactory.connmanager._connections.keys() #获取所有在线用户
		lis.remove(conn.transport.sessionno)                            #移除下线者本身，补充说明：避免和客户端显示重复
		str2 = '%s is logout\\r\\nOnline Users: %d' % (loginTempDict[conn.transport.sessionno],len(lis))
		returnStr = "{'status':1, 'msg':'"+str2+"'}"
		del loginTempDict[conn.transport.sessionno]						#移除登陆缓存
		GlobalObject().netfactory.pushObject(10001, returnStr, lis)      #向用户群发送当前下线者下线信息

#GlobalObject().netfactory.doConnectionMade = doConnectionMade       	#将自定义的登陆后执行的方法绑定到框架, (补充说明：这里就是所谓的重构方法)
GlobalObject().netfactory.doConnectionLost = doConnectionLost       	#将自定义的下线后执行的方法绑定到框架

def checkIsInList(sessionno, username):
	'''检查是否存在缓存中'''
	global loginTempDict
	if sessionno in loginTempDict:
		return False
	else:
		loginTempDict.setdefault(sessionno, username)
		return True

def callbackSingleClientData(_conn, callbackstr):
	if(wtxdebug):
		print 'wtx callbackSingleClientData'
	GlobalObject().netfactory.pushObject(10001, callbackstr, \
		[_conn.transport.sessionno])

@netserviceHandle					# wtx （1）@netserviceHandle这个是必不可少的。（2）下面数字10001也必须“固定”-因为要对应的发送方法过来。
def speak_10001(_conn,data):											#传递过来的规则是[user_id,user_name,user_key,talkStr]
	'''用户发言的方法'''
	global authenticationKey, loginTempDict								#进行用户验证，如果存在缓存中就表明通过验证，如果不存在，就表示第一次登陆，或者其他
	try:
		data = eval(data)
		print data
		isLogin = checkIsInList(_conn.transport.sessionno, str(data[1])) # data[1]包含的就是user名称
	except Exception, e:
		returnStr = "{'status':-1, 'msg':'Data type error.'}|<2s|"
		return callbackSingleClientData(_conn, returnStr)
	if isLogin==False:
		try:
			userkeyCheck = str(data[0])+str(data[1])+authenticationKey
			userkeyCheck = hashlib.md5(userkeyCheck).hexdigest().upper()
			if userkeyCheck!=str(data[2]):
				returnStr = "{'status':-2, 'msg':'User check error.'}|<2s|"
				return callbackSingleClientData(_conn, returnStr)
			else:
				loginTempDict.setdefault(_conn.transport.sessionno, str(data[1]))
		except Exception, e:
			returnStr = "{'status':-1, 'msg':'Data type error.'}|<2s|"
			return callbackSingleClientData(_conn, returnStr)
	try:
		talkStr = str(data[3])
		if talkStr=='':
			return
	except Exception, e:
		returnStr = "{'status':-1, 'msg':'Data type error.'}|<2s|"
		return callbackSingleClientData(_conn, returnStr)
	date = datetime.now() 												#服务器接收时间
	talkStr = talkStr.replace('\r\n', '\\r\\n')
	chat_str = date.strftime("%Y-%m-%d %H:%M:%S") \
	+ ' [ ' + str(data[1]) + ' ]:\\r\\n' + talkStr     				#拼装字符串
	returnStr = "{'status':1, 'msg':'"+chat_str+"'}"
	lis = GlobalObject().netfactory.connmanager._connections.keys() 	#获取所有在线用户
	lis.remove(_conn.transport.sessionno)                           	#移除发言者本身，(补充说明：避免和客户端显示重复)
	GlobalObject().netfactory.pushObject(10001, returnStr, lis)      	#向用户群发送当前发言者发言信息
